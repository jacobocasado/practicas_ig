// Nombre: Jacobo, Apellidos: Casado de Gracia, DNI/pasaporte: 77146828K (DDGG IG curso 20-21)
// *********************************************************************
// **
// ** Informática Gráfica, curso 2019-20
// ** Implementación de la clase 'MallaRevol'
// **
// *********************************************************************

#include "ig-aux.h"
#include "tuplasg.h"
#include "lector-ply.h"
#include "matrices-tr.h"
#include "malla-revol.h"
#include "malla-ind.h"

using namespace std ;

// *****************************************************************************


// Método que crea las tablas de vértices, triángulos, normales y cc.de.tt.
// a partir de un perfil y el número de copias que queremos de dicho perfil.
void MallaRevol::inicializar
(
   const std::vector<Tupla3f> & perfil,     // tabla de vértices del perfil original
   const unsigned               num_copias  // número de copias del perfil
)
{


   int m = perfil.size();
   
   // PARA LOS VERTICES
   // Bucle for por cada copia del perfil. Dentro de cada copia representamos los vertices.
   for (int i = 0; i < num_copias; ++i){

      // Calculamos el angulo que deben de hacer los vertices.
      float angulo = ((2 * M_PI *  i) / (num_copias - 1)); 

      for (int j = 0; j < m; ++j){

         // Aplicamos la rotacion a los vertices.
         // Rotamos el vértice del ejeX (perfilj0) y el vértice del eje z. El vértice y (perfilj1) lo dejamos como está.

         Tupla3f vertices_rotados = { ( perfil[j][0] * cosf(angulo) - perfil[j][2] * sinf(angulo) ) , // Vertice X
                                  perfil[j][1], // Vertice Y
                                  ( perfil[j][0] * sinf(angulo) - perfil[j][2] * cosf(angulo) )
                                  }; // Vertice Z

         // Añadimos el vértice rotado a la lista de vértices.
         vertices.push_back(vertices_rotados);
      }
   }

   // PARA LOS TRIANGULOS (CARAS)
   for (int i = 0; i < (num_copias - 1); ++i){
      for (int j = 0; j < (m - 1); ++j){
         int k = (i * m + j);
         triangulos.push_back({k, k + m, k + m + 1});
         triangulos.push_back({k, k + m + 1, k + 1});
      }
   }
}

// -----------------------------------------------------------------------------
// constructor, a partir de un archivo PLY

MallaRevolPLY::MallaRevolPLY
(
   const std::string & nombre_arch,
   const unsigned      nperfiles
)
{
   ponerNombre( std::string("Malla por revolución del perfil en '"+ nombre_arch + "'" ));
   // COMPLETAR: práctica 2: crear la malla de revolución
   // Leer los vértice del perfil desde un PLY, después llamar a 'inicializar'
   std::vector<Tupla3f> vertices;
   LeerVerticesPLY(nombre_arch, vertices);
   inicializar(vertices, nperfiles);
}

Cilindro::Cilindro
(const int num_verts_per, const unsigned nperfiles)
{
   // La base tiene centro en el origen. La altura y el radio son 1.
   std::vector<Tupla3f> perfil;
    for (int i = 1; i <= num_verts_per; ++i){
        float y = 1/i;
        Tupla3f vertice = {1.0, y, 0.0};
        perfil.push_back(vertice);
    }
    

   inicializar(perfil, nperfiles);
}

Cono::Cono
(const int num_verts_per, const unsigned nperfiles)
{
   // La base tiene centro en el origen. La altura y el radio son 1.
   std::vector<Tupla3f> perfil;
    for (int i = 1; i <= num_verts_per; ++i){
        float y = 1/i;
        float x = 1 - y;
        Tupla3f vertice = {x, y, 0.0};
        perfil.push_back(vertice);
    }
   inicializar(perfil, nperfiles);
}

Esfera::Esfera
(const int num_verts_per, const unsigned nperfiles)
{
{
   std::vector<Tupla3f> perfil;

   Tupla3f q, p;
   p = { 0.0, -1.0, 0.0 };

   for (int i = 0; i <= num_verts_per; i++) {
      float ang = ((M_PI * i) / (num_verts_per - 1));
      float sen = sin(ang);
      float cose = cos(ang);
      q = { p(0) * cose + p(1) * sen , p(1) * cose - p(0) * sen, p(2)};
      perfil.push_back(q);
   }

   ponerNombre(std::string("Malla por revolución del perfil. Esfera"));
   inicializar(perfil, nperfiles);
}
}

